
<?php
  // Create database connection
  $db = mysqli_connect("localhost", "id12574627_broodingspace", "o%-i*H[4ym|DUhFo", "id12574627_name_me");


  
?>